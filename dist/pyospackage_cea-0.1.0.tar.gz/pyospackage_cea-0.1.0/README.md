# Welcome to pyospackage-cea

|        |        |
|--------|--------|
| Package | [![Latest PyPI Version](https://img.shields.io/pypi/v/pyospackage-cea.svg)](https://pypi.org/project/pyospackage-cea/) [![Supported Python Versions](https://img.shields.io/pypi/pyversions/pyospackage-cea.svg)](https://pypi.org/project/pyospackage-cea/)  |
| Meta   | [![Code of Conduct](https://img.shields.io/badge/Contributor%20Covenant-v2.0%20adopted-ff69b4.svg)](CODE_OF_CONDUCT.md) |

*TODO: the above badges that indicate python version and package version will only work if your package is on PyPI.
If you don't plan to publish to PyPI, you can remove them.*

pyospackage-cea is a project that (describe what it does here).

## Get started

You can install this package into your preferred Python environment using pip:

```bash
$ pip install pyospackage-cea
```

TODO: Add a brief example of how to use the package to this section

To use pyospackage-cea in your code:

```python
>>> import pyospackage-cea
>>> pyospackage-cea.hello_world()
```

## Copyright

- Copyright © 2026 Cynthia Agata Limantono.
- Free software distributed under the [MIT License](./LICENSE).
